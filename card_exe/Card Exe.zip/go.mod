module card

go 1.23.5

require golang.org/x/sys v0.31.0
